// Link /exec aplikasimu dari Apps Script (Terapkan → Kelola deployment).
window.APP_LINK = "https://cucibersih-bmwp4y.zedeai2026.workers.dev";
